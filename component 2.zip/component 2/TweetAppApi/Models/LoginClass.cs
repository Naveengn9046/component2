﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TweetApp.Models
{
    public class LoginClass
    {
        public string emailId { get; set; }
        public string password { get; set; }
    }
}
